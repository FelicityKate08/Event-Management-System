##Setup

1. **Navigate to the Project Directory:**

   ```
   cd QR-Attendance-System
   ```


2. **Install dependencies:**

   ```
   pip install -r requirements.txt
   ```
3. **Run the Django Server:**

   ```
   python manage.py runserver 0.0.0.0:8000 
   ```

4. **To Open Attendance Tracker:**

   Open your web browser and go to `http://localhost:8000` to use the system.

